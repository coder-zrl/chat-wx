//事件为委托实现登录和注册
const navbar_right = document.querySelector(".navbar-right");
console.log(navbar_right);
navbar_right.addEventListener("click" , function(e){
    const target = e.target;
    if(target.className == "login"){
        // console.log("登录");
        var btn = document.querySelector(".login-ok");
        console.log(btn);
        btn.addEventListener("click" , function(e){
            var name = document.querySelector(".login-userName").value;
            var pwd = document.querySelector(".login-userPassword").value;
            console.log(name,pwd);
            utils.fetch("api/user/login.php" ,{name,pwd}).then(resp =>{
                //  console.log(resp);
                if(resp.code==200){
                    alert(resp.body.msg);
                    $('#loginModal').modal('hide');
                    // window.open("表格.html");
                    location.replace('表格.html');
                }else{
                    alert(resp.body.msg);
                }
            })
        })
        
    }else if(target.className=="regist"){
        // console.log("注册");
        var btn = document.querySelector(".regist-ok");
        // console.log(btn);
        btn.addEventListener("click" , function(e){
            var name = document.querySelector(".regist-userName").value;
            var pwd = document.querySelector(".regist-userPassword").value;
            console.log(name,pwd);
            utils.fetch("api/user/regist.php", {name:name, pwd:pwd}).then(resp =>{
                // console.log(resp);
                if(resp.code==200){
                    alert(resp.body.msg);
                    $('#registModal').modal('hide');
                }else{
                    alert(resp.body.msg);
                }
            })
        })
    }

})
$('#registModal').on('hidden.bs.modal', function (e) {
    var name = document.querySelector(".login-userName");
    var pwd = document.querySelector(".login-userPassword");
    name.value=pwd.value="";
  })
  $('#loginModal').on('hidden.bs.modal', function (e) {
    var name = document.querySelector(".login-userName");
    var pwd = document.querySelector(".login-userPassword");
    name.value=pwd.value="";
  })
